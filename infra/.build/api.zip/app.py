# api/app.py
import json, os, boto3

# --- AWS clients ---
secrets_client = boto3.client("secretsmanager")

# --- helpers ---
def get_secret():
    """
    Reads JSON from Secrets Manager at the SECRET_NAME.
    Returns {} if not configured yet.
    """
    name = os.environ.get("SECRET_NAME")
    if not name:
        return {}
    val = secrets_client.get_secret_value(SecretId=name)["SecretString"]
    return json.loads(val)

def json_body(event):
    body = event.get("body")
    if not body:
        return {}
    if isinstance(body, str):
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return {}
    return body

def _resp(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            # CORS for browser calls
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body),
    }

# --- main entrypoint (Terraform expects app.handler) ---
def handler(event, context):
    # Extract method + normalize path (strip stage prefix like "/$default" if present)
    rc = event.get("requestContext", {}).get("http", {})
    method = rc.get("method", "GET")
    raw_path = event.get("rawPath") or event.get("path", "/")
    stage = rc.get("stage")
    path = raw_path[len(stage) + 1 :] if stage and raw_path.startswith(f"/{stage}") else raw_path
    if not path:
        path = "/"

    # CORS preflight
    if method == "OPTIONS":
        return _resp(200, {"ok": True})

    # --- routes ---
    if path == "/" and method == "GET":
        return _resp(200, {"ok": True, "message": "Hello from Lambda + HTTP API"})

    if path == "/mesh/link-token" and method == "POST":
        # For now, just prove we can read secrets
        secret = get_secret()
        return _resp(200, {
            "linkToken": "stub-link-token",
            "using": bool(secret),                  # True if secret is present
            "haveKey": bool(secret.get("MESH_API_KEY")),
            "haveClientId": bool(secret.get("MESH_CLIENT_ID"))
        })

    if path == "/mesh/pay" and method == "POST":
        data = json_body(event)
        # Later: call Mesh transfer API with accessToken/amount/network/toAddress
        return _resp(200, {"status": "stubbed", "transferId": "stub-transfer-id", "echo": data})

    if path == "/mesh/portfolio" and method == "GET":
        # Later: read ?accessToken=... and call Mesh portfolio API
        return _resp(200, {"balances": [], "positions": []})

    return _resp(404, {"error": f"Route {method} {path} not found"})
